<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class QuarterController extends Controller
{
    //
}
