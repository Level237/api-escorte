<?php

namespace App\Interfaces\auth;

interface LoginInterface {

    public function login($data);
}
